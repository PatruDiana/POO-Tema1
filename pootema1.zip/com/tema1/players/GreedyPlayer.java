package com.tema1.players;

import com.tema1.goods.Goods;
import java.util.Iterator;
import com.tema1.strategy.PlayerStrategy;
import com.tema1.main.GameInput;

public class GreedyPlayer extends BasePlayer {
    public GreedyPlayer(final int idPlayer) {
        finalScore = initialScore;
        this.idPlayer = idPlayer;
        this.playerStrategy = PlayerStrategy.GREEDY;

    }

    /**
     * calculate the frequency map and choose the legal goods and set the legalgoodsmap parameter.
     * @param round - number of round.
     */
    public void countCards(final int round) {
        super.countCards(round);
        if (round % 2 == 0) {
            // set the illegal goods map
            illegalcount();
        }
    }

    /**
     * implements the greedy's strategy as a sheriff.
     * @param currentSack - the current sack to be checked.
     * @param gameInput - for confiscated cards to be added at the end of the assets order.
     * @param idplayer - the id of the player to be verified.
     * @param size - the number of players.
     * @return the penalty offered by the sheriff.
     */
    public int sheriffGame(final com.tema1.players.Sack currentSack, final GameInput gameInput,
                           final int idplayer, final int size) {
        if (currentSack.getBribe() == 0) {
            return super.sheriffGame(currentSack, gameInput, idplayer, size);
        } else {
            // take the player's bribe and go unverified
            setFinalScore(getFinalScore() + currentSack.getBribe());
            currentSack.setBribe(0);
        }
        return 0;
    }

    /**
     * put the illegal or legal goods in the sack of the player.
     * @param round - the number of the round
     */
    public void putSack(final int round) {
        super.putSack(round);
        // checks if the round is even
        if (round % 2 == 0) {
            Iterator k = getIllegalgoods().keySet().iterator();
            // count if a good is added in the sack
            boolean ok = false;
            while (k.hasNext() && !ok) {
                Goods key = (Goods) k.next();
                Integer value = getIllegalgoods().get(key);
                // put in sack only one illegal good.
                if (!getSack().getCurrentSack().containsKey(key)) {
                    getSack().putsack(key, 1);
                    ok = true;
                } else {
                    Integer contor = getSack().getCurrentSack().get(key);
                    if (contor < value) {
                        getSack().putsack(key, contor + 1);
                        ok = true;
                    } else {
                    }
                }
            }
        }
    }
}
