package com.tema1.players;

import com.tema1.common.Constants;
import com.tema1.goods.Goods;
import com.tema1.goods.GoodsFactory;
import com.tema1.goods.GoodsType;
import com.tema1.strategy.PlayerRoles;
import com.tema1.strategy.PlayerStrategy;
import com.tema1.Comparator.IllegalGoodsComparator;
import com.tema1.Comparator.LegalGoodsComparator;
import com.tema1.main.GameInput;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;

import static com.tema1.common.Constants.INITIALSCORE;

public class BasePlayer {
    protected int idPlayer;
    protected static int initialScore = INITIALSCORE;
    protected int finalScore;

    protected PlayerStrategy playerStrategy;
    protected PlayerRoles playerRoles;

    protected Map<Goods, Integer> table = new HashMap<>();
    protected ArrayList<Integer> currentCards = new ArrayList<Integer>();
    protected Sack sack = new Sack();
    protected static Map<Integer, Goods> goods = GoodsFactory.getInstance().getAllGoods();
    protected Map<Goods, Integer> legalgoodsmap = new HashMap<>();
    protected Map<Goods, Integer> frecquencymap = new HashMap<>();
    protected Map<Goods, Integer> illegalgoods = new java.util.HashMap<>();
    protected int bribesum = 0;

    public BasePlayer() {
        finalScore = initialScore;
    }

    public BasePlayer(final int idPlayer) {
        this.idPlayer = idPlayer;
        finalScore = initialScore;
        this.playerStrategy = PlayerStrategy.BASIC;
    }

    /**
     *
     * @return the id player.
     */
    public  int getIdPlayer() {
        return idPlayer;
    }

    /**
     * set the score with the new finalScore.
     * @param finalScore
     */
    public void setFinalScore(final int finalScore) {
        this.finalScore = finalScore;
    }

    /**
     *
     * @return the final score of the player.
     */
    public int getFinalScore() {
        return finalScore;
    }

    /**
     * set the role of the player with new playerRoles.
     * @param playerRoles
     */
    public void setPlayerRoles(final PlayerRoles playerRoles) {
        this.playerRoles = playerRoles;
    }

    /**
     *
     * @return the role of the player.
     */
    public PlayerRoles getPlayerRoles() {
        return playerRoles;
    }

    /**
     * set the table with the new table.
     * @param table
     */
    public void setTable(final Map<Goods, Integer> table) {
        this.table = table;
    }

    /**
     *
     * @return the table of the player.
     */
    public  Map<Goods, Integer> getTable() {
        return table;
    }

    /**
     * set the legal goods map with new map.
     * @param legalgoodsmap
     */
    public void setLegalgoodsmap(final Map<Goods, Integer> legalgoodsmap) {
        this.legalgoodsmap = legalgoodsmap;
    }

    /**
     *
     * @return the legal goods map of the player.
     */

    public Map<Goods, Integer> getLegalgoodsmap() {
        return legalgoodsmap;
    }

    /**
     *  set the frequency map of cards.
     * @param frecquencymap
     */
    public void setFrecquencymap(final Map<Goods, Integer> frecquencymap) {
        this.frecquencymap = frecquencymap;
    }

    /**
     *
     * @return the frequency map of cards of player.
     */
    public Map<Goods, Integer> getFrecquencymap() {
        return frecquencymap;
    }

    /**
     * set the current cards.
     * @param currentCards
     */
    public void setCurrentCards(final ArrayList<Integer> currentCards) {
        this.currentCards = currentCards;
    }

    /**
     *
     * @return the current cards of the player.
     */
    public ArrayList<Integer> getCurrentCards() {
        return currentCards;
    }

    /**
     * set the sack of the player.
     * @param sack
     */

    public void setSack(final Sack sack) {
        this.sack = sack;
    }

    /**
     *
     * @return the sack of the player.
     */
    public Sack getSack() {
        return sack;
    }

    /**
     *
     * @return the illegal goods map of the player.
     */
    public Map<Goods, Integer> getIllegalgoods() {
        return illegalgoods;
    }

    /**
     * set the illegal goods map of the player.
     * @param illegalgoods
     */
    public void setIllegalgoods(final Map<Goods, Integer> illegalgoods) {
        this.illegalgoods = illegalgoods;
    }

    /**
     *set the money of the player after one subround.
     * @param penalty - the penalty of the player.
     */
    public void money(final int penalty) {
        setFinalScore(getFinalScore() + penalty);
    }

    /**
     *
     * @return the bribesum of the player.
     */
    public int getBribesum() {
        return bribesum;
    }

    /**
     *  calculate the frequency map and choose the legal goods and set the legalgoodsmap parameter.
     * @param round - number of round.
     */
    public void countCards(final int round) {
        // set the frequency map
        for (int count : getCurrentCards()) {
            getFrecquencymap().put(goods.get(count),
                    getFrecquencymap().getOrDefault(goods.get(count), 0) + 1);

        }
        // choose the legal goods  in a map
        Map<Goods, Integer> collect = getFrecquencymap().entrySet().stream()
                .filter(map -> map.getKey().getId() <= Constants.MAXIMLEGALID)
                .collect(java.util.stream.Collectors.toMap(p -> p.getKey(), p -> p.getValue()));

        // set the legalgoods map
        setLegalgoodsmap(sortByValue((HashMap<Goods, Integer>) collect));

        // clear the frequency map
        getFrecquencymap().clear();
    }

    /**
     *
     * @param map - the map to be sorted.
     * @return an ordered map according to frequency, profit and id.
     */
    protected static HashMap<Goods, Integer> sortByValue(final HashMap<Goods, Integer> map) {
        // create a list from elements of HashMap
        List<Map.Entry<Goods, Integer>> list =
                new LinkedList<Map.Entry<Goods, Integer>>(map.entrySet());

        // sort the list
        LegalGoodsComparator legalGoodsComparator = new LegalGoodsComparator();
        Collections.sort(list, legalGoodsComparator);

        // put data from sorted list to hashmap
        HashMap<Goods, Integer> temp = new java.util.LinkedHashMap<Goods, Integer>();
        for (Map.Entry<Goods, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    /**
     * put the legal or illegal goods in the sack of the player.
     * @param round - the number of the round
     */
    public void putSack(final int round) {
        // check if there are no legal goods
        if (getLegalgoodsmap().isEmpty()) {
            // set the illegalgoodsmap.
            illegalcount();
            Iterator k = getIllegalgoods().keySet().iterator();
            // put in sack only one illegal good.
            if (k.hasNext()) {
                Goods key = (Goods) k.next();
                getLegalgoodsmap().put(key, 1);
            }
        }
        // put in sack the legal goods
        Iterator k = getLegalgoodsmap().keySet().iterator();
        if (k.hasNext()) {
            Goods key = (Goods) k.next();
            Integer value = getLegalgoodsmap().get(key);
            getSack().putsack(key, value);
            // set the bribe of sero.
            getSack().setBribe(0);
            // check if the sack contains illegal goods
            if (key.getType() == GoodsType.Illegal) {
                getSack().setGood(goods.get(0));
            } else {
                getSack().setGood(key);
            }
        }
    }

    /**
     * implements the base's strategy as a sheriff.
     * @param currentSack - the current sack to be checked.
     * @param gameInput - for confiscated cards to be added at the end of the assets order.
     * @param idplayer - the id of the player to be verified.
     * @param size - the number of players.
     * @return the penalty offered by the sheriff.
     */
    public int sheriffGame(final Sack currentSack, final GameInput gameInput, final int idplayer,
                           final int size) {
        // check if he can check a player
        if (getFinalScore() >= Constants.SUMOFINVESTIGATION) {
            int penalty = 0;
            // the new sack that contains only the goods that are declared.
            Map<Goods, Integer> newsack = new java.util.HashMap<>();

            Iterator k1 = currentSack.getCurrentSack().keySet().iterator();
            while (k1.hasNext()) {
                Goods key = (Goods) k1.next();
                // check if the goods are declared
                if (!key.equals(currentSack.getGood())) {
                    // calculate the penalty
                    penalty = penalty + key.getPenalty() * currentSack.getCurrentSack().get(key);
                    // put the confiscated card at the end of the assets order.
                    gameInput.getAssetIds().add(key.getId());
                } else {
                    newsack.put(key, currentSack.getCurrentSack().get(key));
                }
            }
            // check if the player is honest of liar
            if (penalty == 0) {
                Iterator k = currentSack.getCurrentSack().keySet().iterator();
                if (k.hasNext()) {
                    Goods key = (Goods) k.next();
                    penalty = key.getPenalty() * currentSack.getCurrentSack().get(key);
                    setFinalScore(getFinalScore() - penalty);
                    // return the penalty and bribe
                    return penalty + currentSack.getBribe();
                }
            } else {
                currentSack.setCurrentSack(newsack);
                setFinalScore(getFinalScore() + penalty);
                return ((-penalty) + currentSack.getBribe());
            }
        }
        // return the bribe
        return currentSack.getBribe();
    }

    /**
     * put the sack items on the table.
     */
    public void putTabel() {
        Iterator k = getSack().getCurrentSack().keySet().iterator();
        while (k.hasNext()) {
            Goods key = (Goods) k.next();
            if (!getTable().containsKey(key)) {
                getTable().put(key, getSack().getCurrentSack().get(key));
            } else {
                Integer i = getTable().get(key);
                getTable().put(key, i + getSack().getCurrentSack().get(key));
            }
        }
        // clear the sack
        getSack().clear();
    }

    /**
     * reset the map at end of the subround.
     */
    public void resetCurrentCards() {
        frecquencymap.clear();
        currentCards.clear();
        legalgoodsmap.clear();
    }

    /**
     * calculate the frequency map and choose the illegal goods
     * and set the illegalgoodsmap parameter.
     */
    public void illegalcount() {
        // set the frecquency map
        for (int count : getCurrentCards()) {
            getFrecquencymap().put(goods.get(count),
                    getFrecquencymap().getOrDefault(goods.get(count), 0) + 1);
        }
        // choose the illegal goods in a map
        Map<Goods, Integer> collect = getFrecquencymap().entrySet().stream()
                .filter(map -> map.getKey().getId() > Constants.MAXIMLEGALID)
                .collect(java.util.stream.Collectors.toMap(p -> p.getKey(), p -> p.getValue()));
        // set the illegal goods map
        setIllegalgoods(sortbyprofit((HashMap<Goods, Integer>) collect));
        getFrecquencymap().clear();
    }

    /**
     *
     * @param map -the map to be sorted.
     * @return an ordered map according to profit and id.
     */
    public static HashMap<Goods, Integer> sortbyprofit(final HashMap<Goods, Integer> map) {
        // create a list from elements of HashMap
        List<Entry<Goods, Integer>> list =
                new java.util.LinkedList<Entry<Goods, Integer>>(map.entrySet());

        // sort the list
        IllegalGoodsComparator illegalGoodsComparator = new IllegalGoodsComparator();
        Collections.sort(list, illegalGoodsComparator);

        // put data from sorted list to hashmap
        HashMap<Goods, Integer> temp = new java.util.LinkedHashMap<Goods, Integer>();
        for (Entry<Goods, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }

    /**
     *
     * @return the scoreboard of player.
     */
    public String toString() {
        return idPlayer + " " + playerStrategy +  " " + finalScore;
    }
}
