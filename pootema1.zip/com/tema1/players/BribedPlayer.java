package com.tema1.players;

import com.tema1.common.Constants;
import com.tema1.goods.Goods;
import com.tema1.strategy.PlayerStrategy;

import java.util.HashMap;
import java.util.Iterator;
public class BribedPlayer extends BasePlayer {
    public BribedPlayer(final int idPlayer) {
        this.idPlayer = idPlayer;
        finalScore = initialScore;
        this.playerStrategy = PlayerStrategy.BRIBED;
    }

    /**
     *calculate the frequency map and choose the legal goods and set the legalgoodsmap parameter.
     * @param round - number of round.
     */
    public void countCards(final int round) {
        super.countCards(round);
        // set the illegal goods map
        illegalcount();
    }

    /**
     * implements the bribed's strategy as a sheriff.
     * @param currentSack - the current sack to be checked.
     * @param gameInput - for confiscated cards to be added at the end of the assets order.
     * @param idplayer - the id of the player to be verified.
     * @param size - the number of players.
     * @return the penalty offered by the sheriff.
     */
    public int sheriffGame(final Sack currentSack, final com.tema1.main.GameInput gameInput,
                           final int idplayer, final int size) {
        if (idplayer - 1 == getIdPlayer() || getIdPlayer() - 1 == idplayer) {
            return super.sheriffGame(currentSack, gameInput, idplayer, size);
        } else if (getIdPlayer() == 0 && idplayer == size - 1) {
            return super.sheriffGame(currentSack, gameInput, idplayer, size);
        } else if (getIdPlayer() == size - 1 && idplayer == 0) {
            return super.sheriffGame(currentSack, gameInput, idplayer, size);
        } else {
            // set the sumbribe.
            bribesum += currentSack.getBribe();
            currentSack.setBribe(0);
        }
        return 0;
    }

    /**
     *put the illegal or legal goods in the sack of the player.
     * @param round - the number of the round
     */
  public void putSack(final int round) {
      // check what strategy to apply
        if (getIllegalgoods().isEmpty()) {
            super.putSack(round);
        } else {
            int nrofillegalsgoods = 0;
            // count illegal goods
            for (Goods goods : getIllegalgoods().keySet()) {
                nrofillegalsgoods += getIllegalgoods().get(goods);
            }
            int money = getFinalScore();
            // check if he can put the appropriate bribe
            if (nrofillegalsgoods > 2 && money > Constants.BRIBESUM
                    && money > Constants.NUMBEROFILLEGLS * Constants.ILLEGALPENALTY) {
                setLegalgoodsmap(sortbyprofit((HashMap<Goods, Integer>) getLegalgoodsmap()));
                Iterator k = getIllegalgoods().keySet().iterator();
                while (k.hasNext()) {
                    Goods key = (Goods) k.next();
                    Integer value = getIllegalgoods().get(key);
                    int nr = 0;
                    for (int i = 0; i < value; i++) {
                        if (money - key.getPenalty() > 0) {
                            money = money - key.getPenalty();
                            nr++;
                        } else {
                            break;
                        }
                    }
                    // put in sack the illegal goods
                    if (nr != 0) {
                        getSack().putsack(key, nr);
                    }
                }
                if (money > 0) {
                     k = getLegalgoodsmap().keySet().iterator();
                     while (k.hasNext()) {
                         Goods key = (Goods) k.next();
                         Integer value = getLegalgoodsmap().get(key);
                         // check if the good is apple
                         int nr = 0;
                         for (int i = 0; i < value; i++) {
                             if (money - key.getPenalty() > 0) {
                                 money = money - key.getPenalty();
                                 nr++;
                             } else {
                                 break;
                             }
                         }
                         //put in sack the legal goods
                         if (nr != 0) {
                             getSack().putsack(key, nr);
                         }
                     }
                }
                // set the declared goods
                getSack().setGood(goods.get(0));
                // set the bribe
                getSack().setBribe(Constants.BRIBESUM);
                // substracts from the score bribe
                setFinalScore(getFinalScore() - Constants.BRIBESUM);
            } else if (nrofillegalsgoods > 0 && money > Constants.BRIBESUM1) {
                setLegalgoodsmap(sortbyprofit((HashMap<Goods, Integer>) getLegalgoodsmap()));
                // number maxim of the illegal goods
               int nrmaxofgoods = 2;
               Iterator k = getIllegalgoods().keySet().iterator();
               while (k.hasNext() && nrmaxofgoods > 0) {
                   int nr = 0;
                   Goods key = (Goods) k.next();
                   Integer value = getIllegalgoods().get(key);
                   if (value <= nrmaxofgoods) {
                       for (int i = 0; i < value; i++) {
                           if (money - key.getPenalty() > 0) {
                               money = money - key.getPenalty();
                               nrmaxofgoods--;
                               nr++;
                           }
                       }
                   } else {
                       for (int i = 0; i < nrmaxofgoods; i++) {
                           if (money - key.getPenalty() > 0) {
                               money = money - key.getPenalty();
                               nrmaxofgoods--;
                               nr++;
                           } else {
                               break;
                           }
                       }
                   }
                   // put in the sack the illegal goods
                   if (nr != 0) {
                       getSack().putsack(key, nr);
                   }
               }
                if (money > 0) {
                    k = getLegalgoodsmap().keySet().iterator();
                    while (k.hasNext()) {
                        Goods key = (Goods) k.next();
                        Integer value = getLegalgoodsmap().get(key);
                        // check if the good is apple
                        int nr = 0;
                        for (int i = 0; i < value; i++) {
                            if (money - key.getPenalty() > 0) {
                                money = money - key.getPenalty();
                                nr++;
                            }
                        }
                        // put in the sack the legal goods
                        if (nr != 0) {
                            getSack().putsack(key, nr);
                        }
                    }
                }
                // set the declared goods
                getSack().setGood(goods.get(0));
                // set the bribe
                getSack().setBribe(Constants.BRIBESUM1);
                // substracts from the score bribe
                setFinalScore(getFinalScore() - Constants.BRIBESUM1);
            } else {
                super.putSack(round);
            }
        }
    }

    /**
     * reset the map at end of the subround.
     */
    public void resetCurrentCards() {
        super.resetCurrentCards();
        bribesum = 0;
    }

}
