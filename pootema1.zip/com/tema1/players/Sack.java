package com.tema1.players;

import com.tema1.common.Constants;
import com.tema1.goods.Goods;

import java.util.HashMap;
import java.util.Map;

public class Sack {
    private Map<Goods, Integer> currentSack = new HashMap<>(Constants.MAXCAPACITY);
    private Goods good;
    private int bribe;
    private int size;

    /**
     * set the current sack with new sack.
     * @param currentSack
     */
    public void setCurrentSack(final Map<Goods, Integer> currentSack) {
        this.currentSack = currentSack;
    }

    /**
     * get the current sack of the player.
     * @return
     */
    public Map<Goods, Integer> getCurrentSack() {
        return currentSack;
    }

    /**
     * get the bribe.
     * @return
     */
    public int getBribe() {
        return bribe;
    }

    /**
     * set the bribe of the player.
     * @param bribe
     */
    public void setBribe(final int bribe) {
        this.bribe = bribe;
    }

    /**
     * set the declared good.
     * @param good
     */
    public void setGood(final Goods good) {
        this.good = good;
    }

    /**
     * get the declared good of the player.
     * @return
     */
    public Goods getGood() {
        return good;
    }

    /**
     * put in sack the goods and the frequency.
     * @param goods - the goods to be added
     * @param freq - the frequency of the goods
     */
    public void putsack(final Goods goods, final int freq) {
        if (Constants.MAXCAPACITY - getSize() >= freq) {
            currentSack.put(goods, freq);
            size += freq;
        } else if (getSize() != Constants.MAXCAPACITY) {
            currentSack.put(goods, Constants.MAXCAPACITY - getSize());
            size = Constants.MAXCAPACITY;
        } else {
        }

    }
    /**
     * clear the sack.
     */
    public void  clear() {
        currentSack.clear();
        bribe = 0;
        good  = null;
        size = 0;
    }

    /**
     * the size of the sack.
     * @return
     */
    public int getSize() {
        return size;
    }
}
