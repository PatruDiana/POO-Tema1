package com.tema1.Comparator;


import com.tema1.goods.Goods;

import java.util.Comparator;
import java.util.Map.Entry;

public class LegalGoodsComparator implements Comparator<Entry<Goods, Integer>> {

    /**
     * compare two legal goods from maps in descending order according to frequency, profit and id.
     * @param o1
     * @param o2
     * @return the difference between
     */
    public int compare(final Entry<Goods, Integer> o1,
                       final Entry<Goods, Integer> o2) {
        int diff = o2.getValue() - o1.getValue();
        if (diff != 0) {
            return diff;
        }
        diff = o2.getKey().getProfit() - o1.getKey().getProfit();
        if (diff != 0) {
            return diff;
        }
        return (o2.getKey().getId() - o1.getKey().getId());

    }
}
