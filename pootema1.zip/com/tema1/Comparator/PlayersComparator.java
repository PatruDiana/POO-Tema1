package com.tema1.Comparator;

import com.tema1.players.BasePlayer;
import java.util.Comparator;

public class PlayersComparator implements Comparator<BasePlayer> {
    /**
     *  compare two players in descending order according to the final score.
     * @param o1
     * @param o2
     * @return
     */
    public int compare(final BasePlayer o1, final BasePlayer o2) {
        int diff = o2.getFinalScore() - o1.getFinalScore();
            return diff;
    }
}
