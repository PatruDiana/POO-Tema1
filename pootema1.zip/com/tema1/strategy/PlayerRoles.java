package com.tema1.strategy;

public enum PlayerRoles {
    SHERIFF, TRADER
}
