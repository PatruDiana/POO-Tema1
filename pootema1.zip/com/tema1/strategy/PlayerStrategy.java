package com.tema1.strategy;

public enum PlayerStrategy {
    BASIC, BRIBED, GREEDY
}
