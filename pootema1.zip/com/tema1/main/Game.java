package com.tema1.main;

import com.tema1.common.Constants;
import com.tema1.goods.Goods;
import com.tema1.goods.GoodsFactory;
import com.tema1.goods.IllegalGoods;
import com.tema1.goods.LegalGoods;
import com.tema1.strategy.PlayerRoles;
import com.tema1.Comparator.PlayersComparator;
import com.tema1.players.BasePlayer;
import com.tema1.players.BribedPlayer;
import com.tema1.players.GreedyPlayer;
import com.tema1.goods.GoodsType;
import java.util.ArrayList;
import java.util.Map;

final class Game {
        private static Game instance = null;
        private ArrayList<com.tema1.players.BasePlayer> listPlayers;
        private static Map<Integer, Goods> goods = GoodsFactory.getInstance().getAllGoods();


    private Game() {
        this.listPlayers = new ArrayList<com.tema1.players.BasePlayer>();
    }

    static Game getInstance() {
        if (instance == null) {
            instance = new Game();
        }
        return instance;
    }

    /**
     * establishes the strategy of each player based on input.
     * @param gameInput
     */
    void strategyPlayer(final GameInput gameInput) {
        for (int i = 0; i < gameInput.getPlayerNames().size(); i++) {
            if (gameInput.getPlayerNames().get(i).equals("basic")) {
                BasePlayer b = new BasePlayer(i);
                listPlayers.add(b);
            } else if (gameInput.getPlayerNames().get(i).equals("greedy")) {
                BasePlayer b = new GreedyPlayer(i);
                listPlayers.add(b);
            } else {
                BasePlayer b = new BribedPlayer(i);
                listPlayers.add(b);
            }

        }

    }

    /**
     *establishes the role of each player according to the sub-round.
     * @param subround
     */
    private void playersroles(final int subround) {
        for (int i = 0; i < listPlayers.size(); i++) {
            if (i == subround) {
                listPlayers.get(i).setPlayerRoles(PlayerRoles.SHERIFF);
                continue;
            }
            listPlayers.get(i).setPlayerRoles(PlayerRoles.TRADER);

        }
    }

    /**
     * the function in which the game is played in rounds and subrounds.
     * @param gameInput
     */
    void startGame(final GameInput gameInput) {
        int indexCards = 0;
        for (int round  = 1; round <= gameInput.getRounds(); round++) {
            for (int subRound = 0; subRound < gameInput.getPlayerNames().size(); subRound++) {
                // establishing strategies
                playersroles(subRound);
                // sharing cards for each player
                for (int nrPlayer = 0; nrPlayer < gameInput.getPlayerNames().size(); nrPlayer++) {
                    // only to those who are traders
                    if (listPlayers.get(nrPlayer).getPlayerRoles() == PlayerRoles.TRADER) {
                        ArrayList<Integer> cards = new ArrayList<>();
                        for (int nrCards = 0; nrCards < Constants.NRMAXCARDS; nrCards++) {
                            cards.add(gameInput.getAssetIds().get(indexCards));
                            indexCards++;
                        }
                        // putting the goods in the sack
                        listPlayers.get(nrPlayer).setCurrentCards(cards);
                        listPlayers.get(nrPlayer).countCards(round);
                        listPlayers.get(nrPlayer).putSack(round);
                    }

                }
                //final subround
                inspectSerif(subRound, gameInput);
                //clear cards
                removeCards(subRound);

            }
        }
        //get bonuses
        getBonus();
        // sorting players by profit
        PlayersComparator playersComparator = new PlayersComparator();
        java.util.Collections.sort(listPlayers, playersComparator);
    }

    /**
     * bonuses for illegal and legal goods.
     */
    private void getBonusGoods() {
        // bonuses for illegal goods
        illegalgetbonus();
        for (int i = 0; i < listPlayers.size(); i++) {
            for (Goods good1 : listPlayers.get(i).getTable().keySet()) {
                listPlayers.get(i).money(good1.getProfit()
                        * listPlayers.get(i).getTable().get(good1));
            }
        }
    }

    /**
     * bonuses for illegal goods.
     */
    private void illegalgetbonus() {
        // the new map that will contain all the legal goods given by the illegal ones.
        Map<Goods, Integer> newtable = new java.util.HashMap<>();
       for (BasePlayer player : listPlayers) {
           for (Goods goods1 : player.getTable().keySet()) {
               if (goods1.getType() == GoodsType.Illegal) {
                   IllegalGoods illegalGoods = (IllegalGoods) goods1;
                   Map<Goods, Integer> illegalmap = illegalGoods.getIllegalBonus();
                   // copying the goods to the newmap.
                   for (Goods goods2 : illegalmap.keySet()) {
                       if (!newtable.containsKey(goods2)) {
                           newtable.put(goods2, illegalmap.get(goods2)
                                   * player.getTable().get(goods1));
                       } else {
                           Integer i = newtable.get(goods2);
                           newtable.put(goods2, i + illegalmap.get(goods2)
                                   * player.getTable().get(goods1));
                       }
                   }
               }
           }
           // copying the goods of the newmap in table of the player.
           for (Goods goods2 : newtable.keySet()) {
               if (!player.getTable().containsKey(goods2)) {
                   player.getTable().put(goods2, newtable.get(goods2));
               } else {
                   Integer i = player.getTable().get(goods2);
                   player.getTable().put(goods2, i + newtable.get(goods2));
               }
           }
           //clear newtable.
           newtable.clear();
       }
    }

    /**
     * get the king and queen bonuses for the legal goods.
     * @param goods1
     */
    private void getKingQueen(final Goods goods1) {
        // player who win the king bonus
        BasePlayer player1 = new BasePlayer();
        // player who win the queen bonus
        BasePlayer player2 = new BasePlayer();
        // frequency of the goods
        int maxim1 = 0, maxim2 = 0;
        for (int i = 0; i < listPlayers.size(); i++) {
            if (listPlayers.get(i).getTable().containsKey(goods1)) {
                if (listPlayers.get(i).getTable().get(goods1) >  maxim1) {
                    maxim2 = maxim1;
                    player2 = player1;
                    maxim1 = listPlayers.get(i).getTable().get(goods1);
                    player1 = listPlayers.get(i);
                } else if (listPlayers.get(i).getTable().get(goods1) > maxim2) {
                    maxim2 = listPlayers.get(i).getTable().get(goods1);
                    player2 = listPlayers.get(i);
                }
            }
        }
        // king bonus
        if (maxim1 != 0) {
            LegalGoods goods2 = (LegalGoods)
                    GoodsFactory.getInstance().getGoodsById(goods1.getId());
            listPlayers.get(player1.getIdPlayer()).money(goods2.getKingBonus());
        }
        //queen bonus
        if (maxim2 != 0) {
            LegalGoods goods2 = (LegalGoods)
                    GoodsFactory.getInstance().getGoodsById(goods1.getId());
            listPlayers.get(player2.getIdPlayer()).money(goods2.getQueenBonus());
        }
    }

    /**
     * bonuses for illegal and legal goods.
     */
    private void getBonus() {
        getBonusGoods();
        for (Goods goods1 : goods.values()) {
            if (goods1.getId() <= Constants.MAXIMLEGALID) {
                getKingQueen(goods1);
            }
        }
    }

    /**
     *the sheriff checks the players' sacks.
     * @param idSerif
     * @param gameInput
     */
    private void inspectSerif(final int idSerif, final GameInput gameInput) {
        // the penalty offered by sherrif
        int penalty = -1;
        for (int i = 0; i < listPlayers.size(); i++) {
            if (listPlayers.get(i).getIdPlayer() != idSerif) {
                    penalty = listPlayers.get(idSerif).sheriffGame(
                            listPlayers.get(i).getSack(), gameInput, i, listPlayers.size());
                    listPlayers.get(i).money(penalty);
                    listPlayers.get(i).putTabel();
            }
        }
        // set the final score of bribed if the has bribe from another player
        listPlayers.get(idSerif).setFinalScore(listPlayers.get(idSerif).getFinalScore()
                + listPlayers.get(idSerif).getBribesum());

    }

    /**
     *resetting the cards at the end of the sub round.
     * @param subRound
     */
    private void removeCards(final int subRound) {
        for (int i = 0; i < listPlayers.size(); i++) {
                if (listPlayers.get(i).getIdPlayer() != subRound) {
                    listPlayers.get(i).resetCurrentCards();
                }
        }
    }

    /**
     * print scoreboard at at the end of the game.
     * @param output
     */
    public void print(final String output) {
            for (BasePlayer player : listPlayers) {
                System.out.println(player.toString());
            }
    }
}
