package com.tema1.common;

public final class Constants {
    // add/delete any constants you think you may use
    public static final int INITIALSCORE = 80;
    public static final int MAXIMLEGALID = 9;
    public static final int SUMOFINVESTIGATION = 16;
    public static final int BRIBESUM  = 10;
    public static final int BRIBESUM1 = 5;
    public static final int NRMAXCARDS = 10;
    public static final int MAXCAPACITY = 8;
    public static final int NUMBEROFILLEGLS = 3;
    public static final int ILLEGALPENALTY = 4;

}
